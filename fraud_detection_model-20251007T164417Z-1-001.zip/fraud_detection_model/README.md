
        # نموذج كشف الاحتيال - حفظ كامل العمل

        ## 📁 محتويات المجلد
        - `lightgbm_fraud_model.pkl`: النموذج المدرب
        - `model_parameters.json`: معلمات النموذج
        - `prediction_results.csv`: نتائج التنبؤات
        - `performance_metrics.json`: مقاييس الأداء
        - `optimal_threshold.json`: عتبة التصنيف المثلى
        - `confusion_matrix.csv`: مصفوفة الارتباك
        - `feature_importance.csv`: أهمية الميزات
        - `threshold_analysis.csv`: تحليل العتبات
        - `model_report.json`: التقرير المفصل

        ## 📊 الرسوم البيانية
        - `roc_curve.png`: منحنى ROC
        - `precision_recall_curve.png`: منحنى Precision-Recall
        - `confusion_matrix_plot.png`: مصفوفة الارتباك (رسم)
        - `feature_importance.png`: أهمية الميزات
        - `threshold_analysis_plot.png`: تحليل العتبات

        ## 🎯 أداء النموذج
        - **AUC-ROC**: 0.9989
        - **Average Precision**: 0.9429
        - **F1-Score**: 0.8675
        - **العتبة المثلى**: 0.8133

        ## 📅 تاريخ الحفظ
        2025-09-08 22:24:15
        